package com.java;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginController
 */
public class LoginController extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username=request.getParameter("username");
		String pwd=request.getParameter("password");
		
		if(username.equals("admin") && pwd.equals("admin"))
		{
					//String url = "http://localhost:8080/SampleData/userdetails";

			URL obj = new URL("http://localhost:8080/SampleData");
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();

			// optional default is GET
			con.setRequestMethod("POST");
			con.setRequestProperty("Content-Type", 
			           "application/json");
			con.setRequestProperty("username", username);
			con.setRequestProperty("password", pwd);
		
			//add request header
			

			int responseCode = con.getResponseCode();
			//System.out.println("\nSending 'POST' request to URL : " + url);
			System.out.println("Response Code : " + responseCode);

			BufferedReader in = new BufferedReader(
			        new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer responseData = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				responseData.append(inputLine);
			}
			in.close();

			//print result
			System.out.println(response.toString());
		}
		else
		{
			response.sendRedirect("error.html");
			return;
		}
	
		/*	try {
			
		  // MySQL database connection
			Class.forName("com.mysql.jdbc.Driver");
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment","root","");    
        PreparedStatement pst = conn.prepareStatement("Select username,password from user where username=? and password=?");
        pst.setString(1, username);
        pst.setString(2, pwd);
        ResultSet rs = pst.executeQuery();                        
        if(rs.next()) {          
        	//response.sendRedirect("success.html");
		//return;  
    		String url = "http://localhost:8080/SampleData/userdetails";

			URL obj = new URL(url);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();

			// optional default is GET
			con.setRequestMethod("POST");
			con.setRequestProperty("Content-Type", 
			           "application/json");
			con.setRequestProperty("username", username);
			con.setRequestProperty("password", pwd);
		
			//add request header
			

			int responseCode = con.getResponseCode();
			System.out.println("\nSending 'POST' request to URL : " + url);
			System.out.println("Response Code : " + responseCode);

			BufferedReader in = new BufferedReader(
			        new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer responseData = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				responseData.append(inputLine);
			}
			in.close();

			//print result
			System.out.println(response.toString());
        }else{
        	response.sendRedirect("error.html");
		return;   
        }
		
			
	
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}  // MySQL database connection

		}
		**/
	}
	

}
